-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Dez 18, 2009 as 10:49 AM
-- Versão do Servidor: 5.1.35
-- Versão do PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `acisai`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `capa_file_name` varchar(255) DEFAULT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `capa_file_size` int(11) DEFAULT NULL,
  `capa_updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` VALUES(11, 'Sorteio Promoção Compra Premiada 2008', 'Imagem_036.jpg', NULL, 2566700, '2009-10-28 17:33:21', '2009-10-28 17:33:25', '2009-10-28 17:33:25');
INSERT INTO `categorias` VALUES(12, 'Sorteio dia dos Pais 2009', 'P8120048.JPG', NULL, 1641750, '2009-10-28 17:35:19', '2009-10-28 17:35:21', '2009-10-28 17:35:21');
INSERT INTO `categorias` VALUES(13, 'Sorteio dia do Agricultor 2009', 'P7290384.JPG', NULL, 739931, '2009-10-28 17:36:44', '2009-10-28 17:36:45', '2009-10-28 17:36:45');
INSERT INTO `categorias` VALUES(14, 'Sorteio dia das Mães', 'P5120603.JPG', NULL, 792809, '2009-10-28 17:38:37', '2009-10-28 17:38:38', '2009-10-28 17:38:38');
INSERT INTO `categorias` VALUES(15, 'Posse da Diretoria 2009', 'SDC10222.JPG', NULL, 2591537, '2009-10-28 17:40:33', '2009-10-28 17:40:36', '2009-10-28 17:40:36');
INSERT INTO `categorias` VALUES(16, 'Jantar do Trabalhador 2009', 'DSC_0529.JPG', NULL, 2534346, '2009-10-28 17:42:34', '2009-10-28 17:42:36', '2009-10-28 17:42:36');
INSERT INTO `categorias` VALUES(17, 'VT Expoibiaçá', 'Prefeito_e_Soberanas.jpg', NULL, 705532, '2009-10-28 17:44:33', '2009-10-28 17:44:34', '2009-10-28 17:44:34');
INSERT INTO `categorias` VALUES(18, 'Lançamento Expoibiaçá', 'A.JPG', NULL, 329075, '2009-10-28 17:45:21', '2009-10-28 17:45:21', '2009-10-28 17:45:21');
INSERT INTO `categorias` VALUES(19, 'ExpoMarau', 'DSC_0764.JPG', NULL, 143295, '2009-10-28 17:46:36', '2009-10-28 17:46:36', '2009-10-28 17:46:36');
INSERT INTO `categorias` VALUES(20, 'Lançamento Expo São João', 'DSC_0171.JPG', NULL, 256875, '2009-10-28 17:47:06', '2009-10-28 17:47:07', '2009-10-28 17:47:07');
INSERT INTO `categorias` VALUES(21, 'Ana Amélia Lemos recebe convite para Expoibiaçá', 'Ana_Amelia_Lemos_1_.jpg', NULL, 727282, '2009-10-28 17:48:07', '2009-10-28 17:48:07', '2009-10-28 17:48:07');
INSERT INTO `categorias` VALUES(22, 'Comitiva da Expoibiaçá divulga feira em Porto Alegre', 'DSC_0123.JPG', NULL, 647445, '2009-10-30 16:36:36', '2009-10-30 16:36:38', '2009-10-30 16:36:38');
INSERT INTO `categorias` VALUES(23, 'Abertura Expoibiaçá', 'DSC_0239.JPG', NULL, 203337, '2009-11-21 18:57:05', '2009-11-21 18:57:06', '2009-11-21 21:37:39');
INSERT INTO `categorias` VALUES(24, 'Expoibiaçá 2009', 'Coro_Vozes_Cristalinas_encataram_o_p_blico_2_.JPG', NULL, 118218, '2009-11-26 16:47:03', '2009-11-26 16:47:04', '2009-11-26 16:48:21');

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `assunto` varchar(255) DEFAULT NULL,
  `mensagem` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `contacts`
--

INSERT INTO `contacts` VALUES(1, 'edipo', 'edipofederle@gmail.com', 'Testing', 'Only ', '2009-11-05 17:20:05', '2009-11-05 17:20:05');
INSERT INTO `contacts` VALUES(2, 'Edipo', 'edipofederle@gmail.com', 'Testing', 'Apenas um teste', '2009-11-06 11:57:28', '2009-11-06 11:57:28');
INSERT INTO `contacts` VALUES(3, 'Edipo', 'edipofederle@gmail.com', 'Teste', 'Teste', '2009-11-06 16:14:48', '2009-11-06 16:14:48');
INSERT INTO `contacts` VALUES(4, 'admin', 'edipofederle@gmail.com', 'Teste', 'teste', '2009-11-07 13:43:12', '2009-11-07 13:43:12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fotos`
--

CREATE TABLE `fotos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imagem_file_name` varchar(255) DEFAULT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `imagem_file_size` int(11) DEFAULT NULL,
  `imagem_updated_at` datetime DEFAULT NULL,
  `categoria_id` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Extraindo dados da tabela `fotos`
--

INSERT INTO `fotos` VALUES(49, 'Ana_Amelia_Lemos_1_.jpg', NULL, 727282, '2009-10-28 17:49:36', '21');
INSERT INTO `fotos` VALUES(50, 'Ana_Amelia_Lemos_2_.jpg', NULL, 781357, '2009-10-28 17:50:44', '21');
INSERT INTO `fotos` VALUES(51, 'Ana_Amelia_Lemos_3_.jpg', NULL, 776023, '2009-10-28 17:51:50', '21');
INSERT INTO `fotos` VALUES(52, 'DSC_0167.JPG', NULL, 169344, '2009-10-28 17:52:24', '20');
INSERT INTO `fotos` VALUES(53, 'DSC_0171.JPG', NULL, 143295, '2009-10-28 17:52:39', '20');
INSERT INTO `fotos` VALUES(54, 'DSC_0728.JPG', NULL, 300003, '2009-10-28 17:53:10', '19');
INSERT INTO `fotos` VALUES(55, 'DSC_0729.JPG', NULL, 265987, '2009-10-28 17:53:37', '19');
INSERT INTO `fotos` VALUES(56, 'DSC_0732.JPG', NULL, 250810, '2009-10-28 17:54:00', '19');
INSERT INTO `fotos` VALUES(57, 'DSC_0739.JPG', NULL, 214795, '2009-10-28 17:54:20', '19');
INSERT INTO `fotos` VALUES(58, 'DSC_0743.JPG', NULL, 268208, '2009-10-28 17:54:46', '19');
INSERT INTO `fotos` VALUES(59, 'DSC_0749.JPG', NULL, 225764, '2009-10-28 17:55:11', '19');
INSERT INTO `fotos` VALUES(60, 'DSC_0764.JPG', NULL, 256875, '2009-10-28 17:55:42', '19');
INSERT INTO `fotos` VALUES(61, 'A.JPG', NULL, 329075, '2009-10-28 17:56:18', '18');
INSERT INTO `fotos` VALUES(62, 'A_4_.JPG', NULL, 302474, '2009-10-28 17:56:38', '18');
INSERT INTO `fotos` VALUES(63, 'A_5_.JPG', NULL, 339206, '2009-10-28 17:57:27', '18');
INSERT INTO `fotos` VALUES(64, 'A_6_.JPG', NULL, 302639, '2009-10-28 17:59:41', '18');
INSERT INTO `fotos` VALUES(65, 'A_7_.JPG', NULL, 404008, '2009-10-28 18:00:11', '18');
INSERT INTO `fotos` VALUES(66, 'A_8_.JPG', NULL, 308414, '2009-10-28 18:00:34', '18');
INSERT INTO `fotos` VALUES(67, 'A_12_.JPG', NULL, 341508, '2009-10-28 18:02:02', '18');
INSERT INTO `fotos` VALUES(68, 'A_13_.JPG', NULL, 372833, '2009-10-28 18:02:31', '18');
INSERT INTO `fotos` VALUES(69, 'Prefeito_e_Soberanas.jpg', NULL, 705532, '2009-10-28 18:03:25', '17');
INSERT INTO `fotos` VALUES(70, 'Rainha_e_Princesa.jpg', NULL, 673820, '2009-10-28 18:04:09', '17');
INSERT INTO `fotos` VALUES(71, 'Soberanas.jpg', NULL, 680236, '2009-10-28 18:04:55', '17');
INSERT INTO `fotos` VALUES(72, 'soberanas_e_Daniel.jpg', NULL, 674297, '2009-10-28 18:05:34', '17');
INSERT INTO `fotos` VALUES(73, 'DSC_0524.JPG', NULL, 2562679, '2009-10-28 18:07:28', '16');
INSERT INTO `fotos` VALUES(74, 'DSC_0529.JPG', NULL, 2534346, '2009-10-28 18:09:13', '16');
INSERT INTO `fotos` VALUES(75, 'DSC_0533.JPG', NULL, 2325352, '2009-10-28 18:11:00', '16');
INSERT INTO `fotos` VALUES(76, 'DSC_0540.jpg', NULL, 360133, '2009-10-28 18:11:32', '16');
INSERT INTO `fotos` VALUES(77, 'DSC_0543.jpg', NULL, 348366, '2009-10-28 18:12:16', '16');
INSERT INTO `fotos` VALUES(78, 'SDC10222.JPG', NULL, 2591537, '2009-10-28 18:14:39', '15');
INSERT INTO `fotos` VALUES(79, 'SDC10227.JPG', NULL, 2559612, '2009-10-28 18:16:32', '15');
INSERT INTO `fotos` VALUES(80, 'SDC10238.JPG', NULL, 2400279, '2009-10-28 18:18:23', '15');
INSERT INTO `fotos` VALUES(81, 'P5120605.JPG', NULL, 798761, '2009-10-28 18:21:00', '14');
INSERT INTO `fotos` VALUES(82, 'P5120607.JPG', NULL, 787508, '2009-10-28 18:22:50', '14');
INSERT INTO `fotos` VALUES(83, 'P5120611.JPG', NULL, 786114, '2009-10-28 18:24:33', '14');
INSERT INTO `fotos` VALUES(84, 'P5160003.JPG', NULL, 1756183, '2009-10-28 18:27:46', '14');
INSERT INTO `fotos` VALUES(85, 'P5160009.JPG', NULL, 1662511, '2009-10-28 18:30:01', '14');
INSERT INTO `fotos` VALUES(86, 'P7280384.JPG', NULL, 800351, '2009-10-28 18:31:29', '13');
INSERT INTO `fotos` VALUES(87, 'P7280385.JPG', NULL, 791018, '2009-10-28 18:32:31', '13');
INSERT INTO `fotos` VALUES(88, 'P7290383.JPG', NULL, 719871, '2009-10-28 18:33:16', '13');
INSERT INTO `fotos` VALUES(89, 'P8120044.JPG', NULL, 1622372, '2009-10-28 18:34:38', '12');
INSERT INTO `fotos` VALUES(90, 'P8120048.JPG', NULL, 1641750, '2009-10-28 18:38:06', '12');
INSERT INTO `fotos` VALUES(91, 'P8120047.JPG', NULL, 1637475, '2009-10-28 18:40:02', '12');
INSERT INTO `fotos` VALUES(92, 'P8120046.JPG', NULL, 1652381, '2009-10-28 18:41:22', '12');
INSERT INTO `fotos` VALUES(93, 'Imagem_036.jpg', NULL, 2566700, '2009-10-28 18:43:48', '11');
INSERT INTO `fotos` VALUES(94, 'Imagem_049.jpg', NULL, 2733332, '2009-10-28 18:46:07', '11');
INSERT INTO `fotos` VALUES(95, 'Imagem_052.jpg', NULL, 2746251, '2009-10-28 18:48:25', '11');
INSERT INTO `fotos` VALUES(96, 'Imagem_055.jpg', NULL, 2708513, '2009-10-28 18:52:25', '11');
INSERT INTO `fotos` VALUES(97, 'SDC10209.JPG', NULL, 878451, '2009-10-28 18:53:46', '11');
INSERT INTO `fotos` VALUES(98, 'DSC_0123.JPG', NULL, 647445, '2009-10-30 16:38:05', '22');
INSERT INTO `fotos` VALUES(99, 'DSC_0074.JPG', NULL, 721088, '2009-10-30 16:40:01', '22');
INSERT INTO `fotos` VALUES(100, 'Dep_Federal_Marco_Maia.JPG', NULL, 192776, '2009-11-21 18:57:55', '23');
INSERT INTO `fotos` VALUES(101, 'DSC_0030.JPG', NULL, 189613, '2009-11-21 18:58:29', '23');
INSERT INTO `fotos` VALUES(102, 'DSC_0145.JPG', NULL, 227646, '2009-11-21 18:58:46', '23');
INSERT INTO `fotos` VALUES(103, 'DSC_0158.JPG', NULL, 174322, '2009-11-21 18:59:00', '23');
INSERT INTO `fotos` VALUES(104, 'DSC_0162.JPG', NULL, 192665, '2009-11-21 19:00:47', '23');
INSERT INTO `fotos` VALUES(105, 'DSC_0164.JPG', NULL, 215285, '2009-11-21 19:01:03', '23');
INSERT INTO `fotos` VALUES(106, 'DSC_0169.JPG', NULL, 170483, '2009-11-21 19:01:13', '23');
INSERT INTO `fotos` VALUES(107, 'DSC_0239.JPG', NULL, 203337, '2009-11-21 19:01:39', '23');
INSERT INTO `fotos` VALUES(108, 'DSC_0315.JPG', NULL, 213935, '2009-11-21 19:01:57', '23');
INSERT INTO `fotos` VALUES(109, 'cantor_Robson.JPG', NULL, 125375, '2009-11-26 16:47:47', '24');
INSERT INTO `fotos` VALUES(110, 'Cantor_Rud.JPG', NULL, 121835, '2009-11-26 16:49:16', '24');
INSERT INTO `fotos` VALUES(111, 'Coro_Vozes_Cristalinas_encataram_o_p_blico.JPG', NULL, 118856, '2009-11-26 16:49:49', '24');
INSERT INTO `fotos` VALUES(112, 'Coro_Vozes_Cristalinas_encataram_o_p_blico_2_.JPG', NULL, 118218, '2009-11-26 16:50:47', '24');
INSERT INTO `fotos` VALUES(113, 'encena_o_de_abertura.JPG', NULL, 134639, '2009-11-26 16:51:03', '24');
INSERT INTO `fotos` VALUES(114, 'Expositores_Externos.JPG', NULL, 121782, '2009-11-26 16:51:40', '24');
INSERT INTO `fotos` VALUES(115, 'Ivar_Pavan_-Presidente_da_Assembleia_Legislativa_RS.JPG', NULL, 117213, '2009-11-26 16:51:57', '24');
INSERT INTO `fotos` VALUES(116, 'Leo_Clube_de_Ibia_.JPG', NULL, 113351, '2009-11-26 16:52:30', '24');
INSERT INTO `fotos` VALUES(117, 'marco_Maia_-Dep_Federal_-_Vice_pres_da_Camara_dos_Dep..JPG', NULL, 122118, '2009-11-26 16:52:53', '24');
INSERT INTO `fotos` VALUES(118, 'Moises_Dametto_-_presidente_da_Amunor.JPG', NULL, 135572, '2009-11-26 16:53:09', '24');
INSERT INTO `fotos` VALUES(119, 'Prefeito_Ulisses_Cecchin.JPG', NULL, 128082, '2009-11-26 16:53:32', '24');
INSERT INTO `fotos` VALUES(120, 'Presidente_da_Acisai_-_Daniel.JPG', NULL, 125282, '2009-11-26 16:53:48', '24');
INSERT INTO `fotos` VALUES(121, 'Presidente_da_Acisai_-_Daniel_Fich_de_Almeida.JPG', NULL, 127115, '2009-11-26 16:54:03', '24');
INSERT INTO `fotos` VALUES(123, 'Protocolo_de_inten_es_com_Agrodanieli.JPG', NULL, 118170, '2009-11-26 16:55:47', '24');
INSERT INTO `fotos` VALUES(124, 'publico_no_Show_Diego_e_Gabriel.JPG', NULL, 224228, '2009-11-26 16:57:06', '24');
INSERT INTO `fotos` VALUES(125, 'Publico_Show_Tche_Guri.JPG', NULL, 113609, '2009-11-26 16:57:27', '24');
INSERT INTO `fotos` VALUES(126, 'Representante_da_Governadora_Yeda_Crusisu_-_Aguida_Mezzomo.JPG', NULL, 131407, '2009-11-26 16:57:45', '24');
INSERT INTO `fotos` VALUES(127, 'Show_Diego_e_Gabriel.JPG', NULL, 118526, '2009-11-26 16:57:58', '24');
INSERT INTO `fotos` VALUES(128, 'Show_do_Tche_Guri.JPG', NULL, 99291, '2009-11-26 16:58:10', '24');
INSERT INTO `fotos` VALUES(129, 'Show_Rud_Robson.JPG', NULL, 100521, '2009-11-26 16:58:24', '24');
INSERT INTO `fotos` VALUES(130, 'Silvana_Covatti_-_Deputada_Estadual.JPG', NULL, 131578, '2009-11-26 16:58:43', '24');
INSERT INTO `fotos` VALUES(131, 'Soberanas_de_Ibia_.JPG', NULL, 114684, '2009-11-26 16:59:04', '24');
INSERT INTO `fotos` VALUES(132, 'Soberanas_e_vice_prefeito_Claudiomiro_Fracasso.JPG', NULL, 111528, '2009-11-26 16:59:23', '24');
INSERT INTO `fotos` VALUES(133, 'Vistantes_aos_expositores_internos.JPG', NULL, 112506, '2009-11-26 16:59:48', '24');

-- --------------------------------------------------------

--
-- Estrutura da tabela `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) DEFAULT NULL,
  `corpo` text,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Extraindo dados da tabela `news`
--

INSERT INTO `news` VALUES(1, 'Liquida Ibiaçá', 'A acisai promoveu de 30/07 à 08/08 a maior liquidação da história de ibiaçá. a liquidação de inverno do comércio associado a acisai. movimentou o mercado local e fomentou as vendas no final da temporada. o presidente da aciasi, daniel fich de almeida afirma que a promoção está ganhando destaque e a cada ano que passa os consumidores podem desfrutar dos bons preços e as constantes melhorias buscadas pelos empresarios ibiaçaenses.', 0, '2009-09-15 17:32:10', '2009-09-15 17:32:10');
INSERT INTO `news` VALUES(2, 'Ganhadora dia dos Pais', 'No dia 12 de agosto a ACISAI, realizou o sorteio da premiação referente ao dia dos pais, na Campanha Compra Premiada 2009, o sorteio foi realizado na sede da Acisai e contou com a presença de membros da diretoria e associados. A contemplada com uma Cesta foi JANESKA TIEPO, portadora da cautela premiada sob o nº (Ver nº com raqueli). O Presidente da Acisai, Sr. Daniel Fich, afirma que a associação vai continuar premiando os consumidores, pois essa é uma forma de valorizar o cliente. A campanha Compra Premiada Acisai 2009, ira sortear dez prêmios para quem comprar no comércio Ibiaçaense, o próximo sorteio ocorrerá no dia 12outubro referente ao dia das crianças. ', 0, '2009-09-15 17:32:31', '2009-09-15 17:32:31');
INSERT INTO `news` VALUES(3, 'Ganhadora dia dos Namorados', 'No dia 16 de junho a ACISAI, realizou o sorteio da premiação referente ao dia dos namorados, na Campanha Compra Premiada 2009, o sorteio foi realizado na sede da Acisai e contou com a presença de membros da diretoria, associados e a primeira dama do município de Ibiaçá Srª Eli Ana Cechin. A contemplada com uma Cesta foi PAULA BOITO, da cidade de Tapejara, portadora da cautela premiada sob o nº 02831, representada na entrega do prêmio pelo seu esposo Dr. Eduardo Berton. O Presidente da Acisai, Sr. Daniel Fich, afirma que a associação vai continuar premiando os consumidores, pois essa é uma forma de valorizar o cliente. A campanha Compra Premiada Acisai 2009, ira sortear dez prêmios para quem comprar no comércio Ibiaçaense, o próximo sorteio ocorrerá no dia 28 de julho referente ao dia do agricultor. ', 0, '2009-09-15 17:32:48', '2009-09-15 17:32:48');
INSERT INTO `news` VALUES(4, 'Dia do Agricultor', 'No dia 28 de julho a ACISAI, realizou o sorteio da premiação referente ao dia do agricultor, na Campanha Compra Premiada 2009, o sorteio foi realizado na sede da Acisai e contou com a presença do presidente da Acisai, Daniel Fich de Almeida, e representantes de algumas empresas associadas, Delma Rech, da loja Sol Confecções, Oberdan Debastiani, do escritório Debas Contabilidade e Adriana Biondo da agropecuária Agropibi e a secretária da Acisai, Raqueli Nunes. A contemplada com um fogareiro duplo foi VANUSA GONÇALVES SANTOS, da cidade de Ibiaçá, portadora da cautela premiada sob o nº 44420, representada na entrega do prêmio pelo seu esposo Flavio dos Santos. O Presidente da Acisai, Sr. Daniel Fich, afirma que a associação vai continuar premiando os consumidores, pois essa é uma forma de valorizar o cliente. A campanha Compra Premiada Acisai 2009, ira sortear dez prêmios para quem comprar no comércio Ibiaçaense, o próximo sorteio ocorrerá no dia 10 de agosto referente ao dia dos pais. \r\n', 0, '2009-09-15 17:33:14', '2009-09-15 17:33:14');
INSERT INTO `news` VALUES(5, 'Sorteio dia das mães', 'No dia 12 de maio a ACISAI, realizou o sorteio da premiação referente ao dia das mães na Campanha Compra Premiada 2009, o sorteio foi realizado na sede da Acisai e contou com a presença de membros da diretoria e autoridades municipais. O contemplado com um Kit Enxoval foi o Sr Ardolino Fiabani, portador do cupon premiado sob o nº 15610. O Presidente da Acisai, Sr. Daniel Fich afirma que a associação vai continuar premiando os consumidores, pois essa é uma forma de valorizar o cliente. A campanha Compra Premiada Acisai 2009, ira sortear dez prêmios para quem comprar no comércio Ibiaçaense, o próximo sorteio ocorrerá no dia 15 de junho referente ao dia dos namorados. ', 0, '2009-09-15 17:33:28', '2009-09-15 17:33:28');
INSERT INTO `news` VALUES(6, 'Soberanas de Ibiaçá prestigiam Expomarau', '<a href="/fotos/19">\r\n<img src="/system/capas/19/small/DSC_0171.JPG" border="0" align="left">\r\n</a>\r\n\r\nAs soberanas de Ibiaçá, Ruani Gabim e Ellen Diana Rampazzo acompanhadas do vice-presidente da Associação Comercial e Industrial de Serviços e Agropecuária de Ibiacá (Acisai), Marco Zanini, participaram da cerimônia de abertura da Expomarau 2009, no dia 09 de outubro. Na oportunidade, Ruani e Elen entregaram convites às soberanas da Expomarau, ao prefeito Vilmar Perin Zanchin e ao presidente da Assembléia Legislativa do Estado, deputado Ivar Pavan. \r\nA Miss Brasil Turismo Mirim, recebeu o convite em mãos para estar em Ibiaça entre os dias 20 a 22 de novembro.\r\nOs convites foram estendidos aos expositores e demais autoridades que lá estiveram.\r\n\r\n<br><br>', 2, '2009-10-09 18:34:07', '2009-10-09 18:36:14');
INSERT INTO `news` VALUES(7, 'IX Expoibiaçá: Atrações ', 'Paralelamente à feira, acontecerão palestras no espaço empreendedor, reuniões da Amunor e Avenor.  <br /> <br />\r\n\r\nDia 20 - Show com Tchê Guri <br/>\r\nDia 21 - Banda Cheiro de Paixão e Show Nacional com Rud e Robson <br/>\r\nDia 22 – Show com Diego e Gabriel - Show infantil com Laira Alves <br/>\r\n<br/> <br/><br/>\r\n\r\n<b>Informações para expositores </b><br /><br />\r\n\r\n54- 3374 1239 ou 9972 4953 <br />\r\nInformações para imprensa <br />\r\nElaine Fontana – Jornalista <br />\r\nFonte Assessoria de Comunicação Ltda.<br />\r\n(54) 9615-1095 <br />\r\n(54) 3344-34 72 <br />\r\nTapejara - RS <br />\r\n', 1, '2009-10-09 18:46:40', '2009-10-09 18:52:18');
INSERT INTO `news` VALUES(8, 'Sucesso no lançamento da IX Expoibiaçá', '<a href="/fotos/18">\r\n<img src="/system/capas/18/small/A.JPG" border="0" align="left">\r\n</a>\r\n\r\nA Associação Comercial Industrial de Serviços e Agropecuária (Acisai) e a prefeitura de Ibiaçá promoveram no sábado, 12 de setembro, o lançamento da IX Expoibiaçá 2009. O evento reuniu cerca de 600 pessoas no Salão Paroquial.  Na oportunidade aconteceu a escolha da rainha e princesa do município e jantar de confraternização.<br /><br />\r\nA Expo acontecerá nos dias 20, 21 e 22 de novembro de 2009 e tem o objetivo de impulsionar o comércio local mostrando as potencialidades de Ibiaçá para o Estado.  O empresário e presidente da Acisai, Daniel Fich de Almeida, destacou que a cada edição, a Expoibiaçá se reafirma em sua missão de estimular os negócios. “Não tenho dúvidas de que a nossa feira vai marcar época”, acredita. <br /><br />\r\n O prefeito, Ulisses Cecchin (PP), disse que o lançamento da Expo foi uma novidade. “É a primeira vez que realizamos este tipo de evento para anunciar a feira. Estamos investindo 150% a mais em relação à edição anterior. Queremos tornar a Expoibiaçá o segundo maior evento do município, depois da Romaria de Nossa Senhora Consoladora”, espera. <br /><br />\r\n            O vice-prefeito, Claudiomiro Fracasso (PT), garantiu apoio aos empresários e pediu a todos para que ajudem na divulgação. “Este será um dos grandes presentes que daremos à comunidade ao completar os 44 anos do município”, afirmou.  <br /><br />\r\n            O parlamento gaúcho esteve representado pelo deputado estadual Gilmar Sossella (PDT) e pelo assessor do deputado Luciano Azevedo (PPS), Rogério Viech. O deputado federal Vilson Covati (PP) também prestigiou o lançamento. “Uma alegria contagiante, a comissão organizadora talentosa, muito unida, estão de parabéns. Eu quero fazer parte desta mudança que Ibiaçá está propondo”, disse. Durante seu discurso, ele anunciou que fará uma emenda parlamentar de R$ 300 mil para pavimentação da avenida de Ibiaçá. “Cidade acolhedora onde milhares de pessoas depositam esperança. Realmente ela merece estar dando este salto de qualidade”, observou Covati.<br /><br />\r\n            O prefeito de Vila Lângaro e presidente da Amunor, Moisés Dametto (PMDB), desejou sucesso aos organizadores. O pároco Pe. Edson Priamo concedeu a benção aos presentes no evento e pediu a colaboração de todos na realização da feira. <br /><br />\r\n<b>Soberanas </b><br /><br />\r\n            Logos após o jantar aconteceu a escolha da rainha e princesa.  Dez candidatas disputaram o título. A rainha 2009/2011 é a estudante Ruani Gambim, 17 anos. A faixa de princesa foi para a estudante Ellen Diana Rampazzo, 16 anos. <br /><br />', 2, '2009-10-09 18:55:01', '2009-10-09 18:58:34');
INSERT INTO `news` VALUES(9, 'Divulgada programação da Expoibiaçá ', '<style>\r\n   .noticia_grande li {\r\n       margin-left: 30px;\r\n}\r\n</style>\r\n<div class="noticia_grande">\r\n\r\n<p>Após o descerramento do banner da feira, foi anunciada a programação completa. Confira:</p><br />\r\n\r\n<ul>\r\n	<b>Dia 20 (sexta-feira)</b><br /><br />\r\n	<b>09h30 Pré-abertura IX Expoibiaçá </b><br /><br />\r\n	<li>10h00 Início da visitação com autoridades locais</li>\r\n	<li>Visitação das escolas do município à IX Expoibiaçá</li>\r\n	<li>13h30Visitação das escolas do município à IX Expoibiaçá</li>\r\n	<li>16h- Reunião da Amunor – No Espaço Empreendedor</li>\r\n	<li>16h - Reunião da Avenor – No Hotel Araucária</li>\r\n	<li>17h - Abertura oficial IX Expoibiaçá</li>\r\n	<li>22h - Encerramento da visitação à IX Expoibiaçá</li>\r\n	<li>22h30 - Show com TCHÊ GURI</li>\r\n</ul><br /><br />\r\n\r\n<uL>\r\n	<b>Dia 21 (sábado)</b><br /><br />\r\n	<b>09h30 Abertura para visitação</b><br /><br />\r\n	<li>10h30 Palestra Agronegócio.... Espaço Empreendedor (SICREDI)</li>\r\n	<li>14h - Palestra Wilson Zanatta. Espaço Empreendedor </li>\r\n	<li>15h - Apresentação de talentos locais</li>\r\n	<li>Encontro da 3ª Idade</li>\r\n	<li>22h Encerramento da visitação</li>\r\n	<li>22h30 Show Nacional com RUD E ROBSON</li>\r\n	<li>Sucessos: A chapa vai esquentar e Tomar um gole</li>\r\n</ul><br /><br />\r\n\r\n<uL>\r\n<b>Dia 22 (domingo)</b><br /><br />\r\n	<b>09h30 Abertura para visitação</b><br /><br />\r\n	<li>10h Celebração ecumênica em homenagem aos 44º aniversário de Ibiaçá.</li>\r\n	<li>14h Show infantil com LAIRA ALVES</li>\r\n	<li>18h Encerramento da IX Expoibiaçá e Show com DIEGO E GABRIEL</li>\r\n </ul>\r\n\r\n\r\n<b>Em todos os dias do evento haverá:</b>\r\n<li> Praça de alimentação diversificada e restaurante</li>\r\n<li>Parque infantil com brinquedos infláveis</li>\r\n<li> Apresentação de artistas locais</li>\r\n<li>Unidade móvel com os cursos profissionalizantes do Sebrae</li>\r\n \r\n<br/><br/>\r\n<p><b>Mais informações</b> <br />\r\nElaine Fontana (Jornalista) <br />\r\nFonte Assessoria de Comunicação Ltda.<br />\r\nCrédito fotos: Tiaraju de Almeida.<br />\r\n(54) 9615-1095</p>\r\n</div>', 1, '2009-10-09 19:09:44', '2009-10-09 19:15:27');
INSERT INTO `news` VALUES(10, 'Comissão participa do lançamento da Expo São João da Urtiga', '<a href="/fotos/20">\r\n<img src="/system/capas/20/small/DSC_0764.JPG" align="left" border="0"></a>\r\n\r\n\r\nO presidente da Acisai, Daniel Fich e sua esposa Adriana, juntamente com a rainha do município de Ibiaçá, Ruani Gambim e princesa Ellen Diana Rampazzo, prestigiaram o lançamento da I Expo São João da Urtiga, no dia 10 de outubro. Fich, comentou que há uma grande mobilização dos ibiaçaenses para a IX Expoibiaça que integra as comemorações dos 44 anos do município. O convite foi entregue ao prefeito de São João da Urtiga, Ederildo Paparico Bachi (PDT) e a presidente da Feira, elisabet Scalco. A comunidade urtiguense foi convidada a participar nos dias de 20 a 22 de novembro da nona edição da feira que pretende atrair cerca de 12 mil pessoas.\r\n\r\n<br /><br />', 2, '2009-10-16 17:11:42', '2009-10-16 17:11:42');
INSERT INTO `news` VALUES(11, 'Cerca de 90% dos estandes já foram comercializados ', 'A comissão organizadora da IX Expoibiçá divulgou nesta semana que já foram comercializados 90% dos espaços destinados aos expositores para a feira que acontecerá entre os dias 20, 21 e 22 de novembro. O presidente da Associação Comercial e Industrial de Serviços e Agropecuária (Acisai), Daniel Fich de Almeida, agradeceu aos empresários de Ibiaçá e da região pela rápida aquisição dos estandes, logo após o lançamento, que aconteceu no dia 12 de setembro. Com o slogan: “Grandes negócios esperam por você!”, a Expoibiaçá 2009, reafirma seu compromisso e missão de impulsionar o comércio local. O município completará no dia 22 de novembro, 44 anos de emancipação. Possui agricultura pujante, com destaque para agroindústrias, frigoríficos, produção de grãos, bacia leiteira, frangos e suínos. No comércio destacam-se a indústria cerâmica, artefatos de cimento e indústria têxtil. Todos os anos, em fevereiro, cerca de 100 mil pessoas visitam o município na Romaria de Nossa Senhora Consoladora. De acordo com o prefeito, Ulisses Cechin (PP), a feira vai se tornar o segundo maior evento do município. A expectativa para a nona edição é de 12 mil visitantes. Os estandes externos, lona de shows e praça de alimentação serão montados em frente ao Santuário de Nossa Senhora Consoladora e Praça Central. Os expositores internos contarão com amplo espaço no salão paroquial. Ao todo serão 83 expositores.', 2, '2009-10-16 17:15:37', '2009-10-16 17:15:37');
INSERT INTO `news` VALUES(12, 'Ana Amélia Lemos recebe convite para Expoibiaçá', '<a href="http://acisai.com/fotos/5">\r\n<img src="/system/capas/5/small/Ana_Amelia_Lemos_1_.jpg" align="left" border="0">\r\n</a>\r\nO presidente da Associação Comercial de Serviços e Agropecuária de Ibiaçá (Acisai), Daniel Fich de Almeida e o secretário da Indústria e Comércio, Luiz Carlos, entregaram o convite da IX Expoibiaçá à jornalista e comentarista do Grupo RBS, Ana Amélia Lemos. \r\n\r\nA oportunidade ocorreu em virtude da realização de um evento promovido pelo Clube Amigos da Terra e Associação Comercial de Tapejara, na noite desta quinta-feira, 22 de outubro, que teve como palestrante a jornalista Ana Amélia Lemos. O tema abordado foi Políticas Agrícolas.\r\n\r\n A Expoibiaçá acontecerá de 20 a 22 de novembro de 2009 no centro da cidade. O município irá comemorar os 44 anos de emancipação político-adminitrativa.\r\n', 2, '2009-10-23 23:47:09', '2009-10-24 00:28:04');
INSERT INTO `news` VALUES(13, 'VT da Expoibiaçá começa a ser produzido', '<a href="http://acisai.com/fotos/6">\r\n<img src="/system/capas/6/small/soberanas_e_Daniel.jpg" align="left" border="0">\r\n</a>\r\n\r\nO VT da Expoibiaçá 2009, começou a ser produzido nesta quinta-feira, 22. Cinegrafistas e produtores percorreram alguns pontos da cidade e do comércio local para mostrar as potencialidades de Ibiaçá que comemora neste ano seus 44 anos de emancipação.\r\n<br />\r\nAs soberanas do município, rainha Ruani Gambim e princesa Ellen Rampazzo, participaram da gravação demonstrando o carisma, beleza e carinho dos ibiaçaenses.\r\n<br />\r\nO VT será reproduzido no mês de novembro na RBS TV Passo Fundo e TV Pampa.\r\n<br />\r\nA realização da feira é da Acisai e Prefeitura de Ibiaçá.\r\n<br><br>\r\n \r\nElaine Fontana - Jornalista\r\n', 2, '2009-10-23 23:47:42', '2009-10-23 23:47:42');
INSERT INTO `news` VALUES(14, 'Comitiva da Expoibiaçá divulga feira na região', 'Nesta terça-feira (20), a comitiva da Expoibiaçá 2009, esteve visitando os municípios de Tapejara, Vila Lângaro, Água Santa, Santa Cecília do Sul, Coxilha, Sertão, Estação, Getúlio Vargas e Charrua. O roteiro faz parte de uma série de visitas que serão realizadas à grande região com o objetivo de divulgar o evento que acontecerá de 20 a 22 de novembro em Ibiaçá, durante as comemorações dos 44 anos de emancipação.\r\n \r\nIbiaçá passa a viver um novo momento. “A IX Expo vai mostrar a diversidade e a riqueza desta terra. Conhecida pelas tradicionais Romarias de Nossa Senhora Consoladora, queremos também torná-la reconhecida pela capacidade empreendedora dos investidores ibiaçaenses”, afirmou o vice-prefeito de Ibiaçá, Claudiomiro Fracasso, durante visita ao presidente da Associação dos Municípios do Nordeste do Estado (Amunor) e prefeito de Vila Lângaro, Moisés Dametto.\r\n \r\nIntegraram a comitiva da Expoibiaçá, a rainha do município, Ruani Gambim, princesa Ellen Rampazzo e o presidente da Expoibiaçá, Luiz Lusa, que estenderam o convite ao prefeito de Tapejara Seger Menegaz, prefeito de Água Santa, Antonio Alfredo de Souza; prefeito de Santa Cecília do Sul, Rober Girardi; prefeito de Coxilha, Clemir Rigo; prefeito de Sertão, Aldemir Sachet, prefeita de Estação, Cirilde Maria Braciak, prefeito de Getúlio Vargas, Pedro Paulo Prezzotto e prefeito de Charrua, Luiz Carlos Franklin da Silva.\r\n \r\nCom a profissionalização da Expoibiaçá haverá maior número de expositores, infra-estrutura redobrada, área de lazer, ampla praça de alimentação, além de diversos shows. “Em nome dos Governos Municipais estamos convidando a toda comunidade regional para que venham participar conosco”, enfatizou Lusa.\r\n \r\nO evento será realizado no centro de Ibiaçá, abrangendo a praça central, a frente do Santuário Nossa Senhora Consoladora e os dois andares do centro paroquial para expositores internos. Os expositores externos também terão infra-estrutura padrão para mostra e comercialização de produtos.', 2, '2009-10-23 23:49:01', '2009-10-23 23:49:01');
INSERT INTO `news` VALUES(15, 'Comitiva da Expoibiaçá divulga feira em Porto Alegre', 'Uma comitiva da Expoibiaçá 2009 divulga a feira nesta quarta (28) e\r\nquinta-feira (29), em Porto Alegre. O roteiro faz parte de uma série de\r\nvisitas que são realizadas em diversos municípios. O evento acontecerá de 20\r\na 22 de novembro em Ibiaçá, na região nordeste do Estado, durante as\r\ncomemorações dos 44 anos de emancipação.\r\n\r\n\r\n\r\nPara o prefeito do município, Ulisses Cecchin (PP), a exposição vai mostrar\r\na diversidade e a riqueza local. “Somos conhecidos pelas tradicionais\r\nRomarias de Nossa Senhora Consoladora, queremos agora projetar a capacidade\r\nempreendedora dos ibiaçaenses”, acredita.\r\n\r\n<br /><br />\r\n\r\n\r\nAlém do prefeito integraram a comitiva de divulgação da Expoibiaçá a rainha\r\ndo município, Ruani Gambin, princesa Elen Diana Rampazzo e o presidente da\r\nAssociação Comercial e Industrial de Serviços e Agropecuária (Acisai),\r\nDaniel Fich de Almeida. “Com a profissionalização da Expoibiaçá, haverá\r\nmaior número de expositores, infra-estrutura redobrada, área de lazer, ampla\r\npraça de alimentação, além de diversos shows”, destaca Almeida.\r\n\r\n\r\n<br /><br />\r\n\r\nO evento será realizado no centro de Ibiaçá, abrangendo a praça central, a\r\nfrente do Santuário Nossa Senhora Consoladora e os dois andares do centro\r\nparoquial para expositores internos. Os expositores externos também terão\r\ninfra-estrutura padrão para mostra e comercialização de produtos. Ao todo\r\nserão 83 expositores.\r\n\r\n\r\n<br /><br />\r\nCom o slogan: “Grandes negócios esperam por você!”, a Expoibiaçá 2009,\r\nreafirma seu compromisso e missão de impulsionar o comércio local.  O\r\nmunicípio completará no dia 22 de novembro, 44 anos de emancipação.\r\nApresenta agricultura pujante com destaque para agroindústrias, produção de\r\ngrãos, bacia leiteira, frangos e suínos. No comércio destacam-se a indústria\r\ncerâmica, artefatos de cimento e indústria têxtil.\r\n<br /><br />\r\nTodos os anos, em fevereiro, cerca de 100 mil pessoas visitam o município na\r\nRomaria de Nossa Senhora Consoladora. De acordo com o prefeito a feira vai\r\nse tornar o segundo maior evento do município. A expectativa para esta\r\nedição é de 15 mil visitantes.\r\n\r\n<br /><br />\r\n\r\n*Shows*\r\n<br />\r\nDia 20/11 - Show com Tchê Guri\r\n<br />\r\nDia 21/11 - Banda Cheiro de Paixão e Show Nacional com Rud e Robson\r\n<br />\r\nDia 22/11 - Show com Diego e Gabriel - Show infantil com Laira Alves\r\n<br /><br />\r\n*Passaportes - R$ 20,00*\r\n\r\nDireito a todos os shows.\r\n<br />\r\nLegendas:\r\n\r\nComitiva faz convite ao presidente da Assembleia Legislativa\r\nComitiva da Expoibiaçá em visita a Porto Alegre\r\n<br /><br />\r\n\r\n\r\n*Informações: Elaine Fontana – Jornalista – Fonte Comunicação Ltda.*\r\n\r\n*54 9615.1095*', 2, '2009-10-30 16:47:06', '2009-10-30 16:47:06');
INSERT INTO `news` VALUES(16, 'Tudo pronto para IX Expoibiaçá', 'Abre nesta sexta-feira (20),  a nona edição da Expoibiçá 2009. A solenidade de abertura será às 18 horas junto à lona de shows. Nesta quinta-feira (19), está sendo finalizado o trabalho de montagem dos mais de 80 expositores locais e regionais.\r\n<br><br>\r\nSerão mais de 600 m² de exposição interna e aproximadamente 2mil m² de exposição externa. O evento acontece no centro da cidade, em frente ao Santuário de Nossa Senhora Consoladora de Ibiaçá, a cada dois anos.\r\n<br><br>\r\nO show de abertura desta sexta-feira (20) é com Tchê Guri, no sábado (21) show nacional com Rud e Robson, com exclusividade para a Expoibiaçá. São autores do sucesso: “A chapa vai esquentar”. Ainda no sábado, show com a Banda Cheiro de Paixão. No domingo à tarde show infantil gratuito com Laira Alves e o encerramento com a dupla Diego e Gabriel, além de outras atrações da região como é o caso do violonista Carlos Ariel.<br><br>\r\n\r\nConforme o presidente da Associação Comercial de Serviços e Agropecuária (Acisai), Daniel Fich de Almeida, a comissão organizadora esta fazendo um trabalho sensacional, equipe motivada, associados participando, isso tudo tem sido determinante para alcançarmos e até superarmos todas as metas propostas. “Estamos trabalhando para oferecer o melhor aos nossos expositores e visitantes”, destacou.<br><br>\r\n\r\n<b>Ciclo de palestras</b>\r\n<br>\r\nTemas importantes ligados à economia, agricultura e comércio estão sendo discutidos durante esta semana através de palestras que integram a programação dos 44 anos do município. Hoje (19), a palestra será sobre as perspectivas de mercado com o engenheiro agrônomo da Emater de Passo Fundo, Luiz Ataídes Jacobsen.<br><br>\r\n\r\nO prefeito Ulisses Cecchin (PP), lembra que nesta sexta-feira a tarde, acontece a reunião dos municípios que integram a Amunor. “Convidamos a todos para nos visitarem e compartilharem desse importante momento para Ibiacá e realizarem bons negócios.”, afirma. <br><br>\r\n\r\n\r\n<b>Programação </b>\r\n\r\n<b>Dia 20 (sexta-feira)</b>\r\n<br>\r\n09h30 Pré-abertura IX Expoibiaçá<br>\r\n\r\n10h00 Início da visitação com autoridades locais\r\n<br>\r\n10h00Visitação das escolas do município à IX Expoibiaçá\r\n<br>\r\n13h30Visitação das escolas do município à IX Expoibiaçá\r\n<br>\r\n13h30 Reunião da Amunor – Espaço Empreendedor\r\n<br>\r\n18h00 Abertura oficial IX Expoibiaçá\r\n<br>\r\n22h00 Encerramento da visitação à IX Expoibiaçá\r\n<br>\r\n22h30 Show com TCHÊ GURI\r\n<br>\r\n <br>\r\n\r\n<b>Dia 21 (sábado)</b>\r\n<br>\r\n09h30 Abertura para visitação\r\n<br>\r\n10h00 Reunião da Avenor – Espaço Empreeendedor\r\n<br>\r\n14h30 Palestra Agronegócio... Espaço Empreendedor patrocinada pelo SICREDI\r\n<br>\r\n14h30 Apresentação de talentos locais – Espaço Cultural\r\n<br>\r\n16h00 Encontro da 3ª Idade -\r\n<br>\r\n22h00 Encerramento da visitação\r\n<br>\r\n22h30 Show Nacional com RUD E ROBSON  de São Paulo Autores dos sucessos: A chapa vai esquentar e Tomar um gole. Após show baile com Banda Cheiro de Paixão .\r\n<br>\r\n <br>\r\n\r\n<b>Dia 22 (domingo)</b>\r\n<br>\r\n9h Missa no Santuário dos 44 anos de Ibiaçá\r\n<br>\r\n10h  Abertura para visitação\r\n<br>\r\n14h Show infantil gratuito com LAIRA ALVES\r\n<br>\r\n18h Encerramento da visitação à IX Expoibiaçá\r\n<br>\r\n18h30 Show de encerramento com DIEGO E GABRIEL\r\n<br>\r\nEm todos os dias do evento haverá:\r\n<br>\r\n- Praça de alimentação diversificada e restaurante\r\n<br>\r\n- Parque infantil com brinquedos infláveis\r\n<br>\r\n- Apresentação de artistas locais\r\n<br>\r\n- Mostra de artesanato\r\n<br>\r\n- Agricultura familiar – Divulgação e comercialização de produtos da culinária local\r\n<br>\r\n<br>', 2, '2009-11-20 16:21:59', '2009-11-20 16:21:59');
INSERT INTO `news` VALUES(17, 'Expoibiaçá reúne grande público no primeiro dia da feira ', 'A solenidade de abertura da IX Expoibiçá aconteceu com grande sucesso nesta sexta-feira, 20.<br ><br>\r\n\r\nPresença de autoridades como presidente da Assembléia Legislativa, deputado Ivar Pavan (PT), técnica da Emater Aguida Mezzomo que esteve representando a governadora Yeda Crusius, além do deputado federal Marco Maia (PT) e estaduais, Gilmar Sossella (PDT), Silvana Covatti (PP) prefeitos e vereadores da região, expositores e comunidade regional.<br ><br>\r\n\r\nO presidente da Feira, Luiz Ângelo Lusa, declarou oficialmente aberta a Exposição desejando sucesso a todos.<br ><br>\r\n\r\nDurante seu discurso o presidente da Acisai (Associação Comercial e Industrial de Serviços e Agropecuária), Daniel Fich de Almeida, deu as boas vindas aos visitantes e destacou o potencial empreendedor dos empresários ibiaçaenses. O prefeito Ulisses Cecchin (PP), reiterou em seu discurso o aniversário de 44 anos do município que serão completados neste domingo, 22. Ele também parabenizou a Acisai pela organização do evento e a todos que estão colaborando para o êxito da feira.<br ><br>     \r\n\r\nNa oportunidade assinou o protocolo de intenção com a empresa Agrodanieli que deverá investir R$ 13 milhões no incubatório avícola a partir do inicio de 2010.  De acordo com o prefeito, as instalações deverão ser próximas ao perímetro urbano. “Estamos orgulhosos por esta conquista e felizes por estarmos proporcionando emprego e renda”. A empresa vai gerar 70 empregos diretor e aproximadamente 40 indiretos.<br ><br>    \r\n\r\n\r\nApesar da chuva, o público lotou a lona de shows para prestigiar o Grupo Tche Guri.<br ><br>\r\n\r\nHoje há uma grande expectativa para o show nacional da dupla Rud e Robson a partir das 22h30min. Depois segue a festa com Banda Cheiro de Paixão.<br ><br>\r\n\r\nNo domingo à tarde show infantil gratuito com Laira Alvez. Diego e Gabriel se apresentam as 18h30.<br ><br> \r\n\r\nNão há cobrança de ingressos para visitar a Expo, que acontece no centro de Ibiaçá. <br ><br>', 2, '2009-11-21 18:53:54', '2009-11-21 18:53:54');
INSERT INTO `news` VALUES(18, 'Cerca de 10 mil pessoas visitaram IX Expoibiaçá ', 'A IX Expoibiaçá, realizada entre os dias 20 e 22 de novembro, recebeu cerca de 10 mil visitantes, de acordo com os organizadores. A solenidade de abertura da IX Expoibiçá aconteceu com grande sucesso nesta sexta-feira, 20. Presença de importantes autoridades como o presidente da Assembléia Legislativa, deputado Ivar Pavan (PT), técnica da Emater Águida Mezzomo que esteve representando a governadora Yeda Crusius, além do deputado federal Marco Maia (PT) e deputados estaduais, Gilmar Sossella (PDT), Silvana Covatti (PP) prefeitos e vereadores da região, expositores e comunidade regional.<br /><br />\r\n \r\nO presidente da Feira, Luiz Ângelo Lusa, declarou oficialmente aberta a Exposição desejando sucesso a todos. Durante seu discurso o presidente da Acisai (Associação Comercial e Industrial de Serviços e Agropecuária), Daniel Fich de Almeida, desejou bons negócios e deu as boas vindas aos visitantes destacando o potencial empreendedor dos empresários ibiaçaenses. <br /><br />\r\n \r\nO prefeito Ulisses Cecchin (PP), reiterou em seu discurso o aniversário de 44 anos do município. Ele também parabenizou a Acisai pela organização do evento e a todos que colaboraram para o êxito da feira. Ainda durante a solenidade, o prefeito assinou o protocolo de intenção com a empresa Agrodanieli que deverá investir R$ 13 milhões num incubatório avícola a partir do inicio de 2010.  De acordo com o prefeito, as instalações deverão ser próximas ao perímetro urbano. “Estamos orgulhosos por esta conquista e felizes por estarmos proporcionando emprego e renda”. A empresa vai gerar 70 empregos diretor e aproximadamente 40 indiretos.   <br /><br />\r\n \r\nShows contagiaram visitantes \r\nApesar da chuva, o público lotou a lona de shows em todas as noites. Na sexta-feira, o Grupo Tchê Guri animou o público. \r\nNo sábado foi a vez da dupla Rud e Robson de São Paulo fazerem a festa com público da Expoibiaçá. Pra fechar a noite subiu ao palco Banda Cheiro de Paixão.\r\nNo domingo à tarde a garotinha Laira Alvez, fez show infantil e agitou a criançada. \r\nO show de encerramento da Expoibiaçá no domingo, contou com um público ainda maior. Os jovens catarinenses Diego e Gabriel caíram no gosto da galera e agitaram a noite. \r\nA próxima edição da Expoibiaçá deve acontecer em 2011. A realização desta edição foi da Acisai com apoio da Prefeitura Municipal. Organização: Fonte Comunicação; AM9 Produções e JD Shows.<br /><br />\r\n<hr><br />\r\nElaine Fontana<br>\r\nJornalista<br >\r\n54 9615.1095<br /> ', 1, '2009-11-25 12:01:05', '2009-11-25 12:01:58');
INSERT INTO `news` VALUES(19, 'Cerca de 10 mil pessoas visitaram IX Expoibiaçá ', 'A IX Expoibiaçá, realizada entre os dias 20 e 22 de novembro, recebeu cerca de 10 mil visitantes, de acordo com os organizadores. A solenidade de abertura da IX Expoibiçá aconteceu com grande sucesso nesta sexta-feira, 20. Presença de importantes autoridades como o presidente da Assembléia Legislativa, deputado Ivar Pavan (PT), técnica da Emater Águida Mezzomo que esteve representando a governadora Yeda Crusius, além do deputado federal Marco Maia (PT) e deputados estaduais, Gilmar Sossella (PDT), Silvana Covatti (PP) prefeitos e vereadores da região, expositores e comunidade regional.\r\n\r\n <br><br>\r\n\r\nO presidente da Feira, Luiz Ângelo Lusa, declarou oficialmente aberta a Exposição desejando sucesso a todos. Durante seu discurso o presidente da Acisai (Associação Comercial e Industrial de Serviços e Agropecuária), Daniel Fich de Almeida, desejou bons negócios e deu as boas vindas aos visitantes destacando o potencial empreendedor dos empresários ibiaçaenses.\r\n\r\n <br><br>\r\n\r\nO prefeito Ulisses Cecchin (PP), reiterou em seu discurso o aniversário de 44 anos do município. Ele também parabenizou a Acisai pela organização do evento e a todos que colaboraram para o êxito da feira. Ainda durante a solenidade, o prefeito assinou o protocolo de intenção com a empresa Agrodanieli que deverá investir R$ 13 milhões num incubatório avícola a partir do inicio de 2010.  De acordo com o prefeito, as instalações deverão ser próximas ao perímetro urbano. “Estamos orgulhosos por esta conquista e felizes por estarmos proporcionando emprego e renda”. A empresa vai gerar 70 empregos diretor e aproximadamente 40 indiretos.', 2, '2009-11-26 16:32:10', '2009-11-26 16:32:10');
INSERT INTO `news` VALUES(20, 'Shows contagiaram visitantes ', 'Apesar da chuva, o público lotou a lona de shows em todas as noites. Na sexta-feira, o Grupo Tchê Guri animou o público.\r\n\r\n<br><br>\r\n\r\n No sábado foi a vez da dupla Rud e Robson de São Paulo fazerem a festa com público da Expoibiaçá. Pra fechar a noite subiu ao palco Banda Cheiro de Paixão.\r\n\r\n<br><br>\r\n\r\n No domingo à tarde a garotinha Laira Alvez, fez show infantil e agitou a criançada.\r\n\r\n<br><br>\r\n\r\nO show de encerramento da Expoibiaçá no domingo, contou com um público ainda maior. Os jovens catarinenses Diego e Gabriel caíram no gosto da galera e agitaram a noite.\r\n\r\n<br><br>\r\n\r\nA próxima edição da Expoibiaçá deve acontecer em 2011. A realização desta edição foi da Acisai com apoio da Prefeitura Municipal. Organização: Fonte Comunicação; AM9 Produções e JD Shows.', 2, '2009-11-26 16:34:05', '2009-11-26 16:34:05');

-- --------------------------------------------------------

--
-- Estrutura da tabela `schema_migrations`
--

CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `schema_migrations`
--

INSERT INTO `schema_migrations` VALUES('20090714134334');
INSERT INTO `schema_migrations` VALUES('20090715135303');
INSERT INTO `schema_migrations` VALUES('20090715135341');
INSERT INTO `schema_migrations` VALUES('20090720165714');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
